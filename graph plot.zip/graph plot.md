```python
import numpy as np
```


```python
import pandas as pd
```


```python
pip install pandas
```

    Requirement already satisfied: pandas in c:\users\hassan-sodiq\anaconda3\lib\site-packages (1.2.4)
    Requirement already satisfied: python-dateutil>=2.7.3 in c:\users\hassan-sodiq\anaconda3\lib\site-packages (from pandas) (2.8.1)
    Requirement already satisfied: pytz>=2017.3 in c:\users\hassan-sodiq\anaconda3\lib\site-packages (from pandas) (2021.1)
    Requirement already satisfied: numpy>=1.16.5 in c:\users\hassan-sodiq\anaconda3\lib\site-packages (from pandas) (1.20.1)
    Requirement already satisfied: six>=1.5 in c:\users\hassan-sodiq\anaconda3\lib\site-packages (from python-dateutil>=2.7.3->pandas) (1.15.0)
    Note: you may need to restart the kernel to use updated packages.
    


```python
df= pd.read_csv('C:/Users/Hassan-Sodiq/Downloads/StudentsPerformance.csv')
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>gender</th>
      <th>race/ethnicity</th>
      <th>parental level of education</th>
      <th>lunch</th>
      <th>test preparation course</th>
      <th>math score</th>
      <th>reading score</th>
      <th>writing score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>female</td>
      <td>group B</td>
      <td>bachelor's degree</td>
      <td>standard</td>
      <td>none</td>
      <td>72</td>
      <td>72</td>
      <td>74</td>
    </tr>
    <tr>
      <th>1</th>
      <td>female</td>
      <td>group C</td>
      <td>some college</td>
      <td>standard</td>
      <td>completed</td>
      <td>69</td>
      <td>90</td>
      <td>88</td>
    </tr>
    <tr>
      <th>2</th>
      <td>female</td>
      <td>group B</td>
      <td>master's degree</td>
      <td>standard</td>
      <td>none</td>
      <td>90</td>
      <td>95</td>
      <td>93</td>
    </tr>
    <tr>
      <th>3</th>
      <td>male</td>
      <td>group A</td>
      <td>associate's degree</td>
      <td>free/reduced</td>
      <td>none</td>
      <td>47</td>
      <td>57</td>
      <td>44</td>
    </tr>
    <tr>
      <th>4</th>
      <td>male</td>
      <td>group C</td>
      <td>some college</td>
      <td>standard</td>
      <td>none</td>
      <td>76</td>
      <td>78</td>
      <td>75</td>
    </tr>
  </tbody>
</table>
</div>




```python
#In our data set, there are 518 female and 482 male.
df.gender.value_counts()
```




    female    518
    male      482
    Name: gender, dtype: int64




```python
#Our data frame has 1000 rows and 8 columns.
df.shape
```




    (1000, 8)




```python
#the count of each race/ethnicity
df['race/ethnicity'].value_counts()
```




    group C    319
    group D    262
    group B    190
    group E    140
    group A     89
    Name: race/ethnicity, dtype: int64




```python
# the count of different lunch
df['lunch'].value_counts()
```




    standard        645
    free/reduced    355
    Name: lunch, dtype: int64




```python
df['test preparation course'].value_counts()
```




    none         642
    completed    358
    Name: test preparation course, dtype: int64




```python
df.gender.value_counts
```




    <bound method IndexOpsMixin.value_counts of 0      female
    1      female
    2      female
    3        male
    4        male
            ...  
    995    female
    996      male
    997    female
    998    female
    999    female
    Name: gender, Length: 1000, dtype: object>




```python

```


```python

```


```python
df['gender']
```




    0      female
    1      female
    2      female
    3        male
    4        male
            ...  
    995    female
    996      male
    997    female
    998    female
    999    female
    Name: gender, Length: 1000, dtype: object




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>math score</th>
      <th>reading score</th>
      <th>writing score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1000.00000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>66.08900</td>
      <td>69.169000</td>
      <td>68.054000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>15.16308</td>
      <td>14.600192</td>
      <td>15.195657</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.00000</td>
      <td>17.000000</td>
      <td>10.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>57.00000</td>
      <td>59.000000</td>
      <td>57.750000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>66.00000</td>
      <td>70.000000</td>
      <td>69.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>77.00000</td>
      <td>79.000000</td>
      <td>79.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>100.00000</td>
      <td>100.000000</td>
      <td>100.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info
```




    <bound method DataFrame.info of      gender race/ethnicity parental level of education         lunch  \
    0    female        group B           bachelor's degree      standard   
    1    female        group C                some college      standard   
    2    female        group B             master's degree      standard   
    3      male        group A          associate's degree  free/reduced   
    4      male        group C                some college      standard   
    ..      ...            ...                         ...           ...   
    995  female        group E             master's degree      standard   
    996    male        group C                 high school  free/reduced   
    997  female        group C                 high school  free/reduced   
    998  female        group D                some college      standard   
    999  female        group D                some college  free/reduced   
    
        test preparation course  math score  reading score  writing score  
    0                      none          72             72             74  
    1                 completed          69             90             88  
    2                      none          90             95             93  
    3                      none          47             57             44  
    4                      none          76             78             75  
    ..                      ...         ...            ...            ...  
    995               completed          88             99             95  
    996                    none          62             55             55  
    997               completed          59             71             65  
    998               completed          68             78             77  
    999                    none          77             86             86  
    
    [1000 rows x 8 columns]>




```python
df['race/ethnicity'].values
```




    array(['group B', 'group C', 'group B', 'group A', 'group C', 'group B',
           'group B', 'group B', 'group D', 'group B', 'group C', 'group D',
           'group B', 'group A', 'group A', 'group C', 'group C', 'group B',
           'group C', 'group C', 'group D', 'group B', 'group D', 'group C',
           'group D', 'group A', 'group B', 'group C', 'group C', 'group D',
           'group D', 'group B', 'group E', 'group D', 'group E', 'group E',
           'group D', 'group D', 'group D', 'group B', 'group C', 'group C',
           'group B', 'group B', 'group E', 'group B', 'group A', 'group C',
           'group D', 'group C', 'group E', 'group E', 'group C', 'group D',
           'group C', 'group C', 'group E', 'group D', 'group D', 'group C',
           'group E', 'group A', 'group A', 'group C', 'group D', 'group B',
           'group D', 'group C', 'group B', 'group C', 'group D', 'group D',
           'group A', 'group C', 'group C', 'group B', 'group E', 'group A',
           'group D', 'group E', 'group B', 'group B', 'group A', 'group E',
           'group D', 'group C', 'group C', 'group D', 'group A', 'group D',
           'group C', 'group C', 'group C', 'group C', 'group B', 'group C',
           'group B', 'group E', 'group D', 'group D', 'group B', 'group D',
           'group D', 'group B', 'group C', 'group C', 'group D', 'group E',
           'group B', 'group B', 'group D', 'group C', 'group A', 'group D',
           'group E', 'group C', 'group B', 'group D', 'group D', 'group C',
           'group C', 'group B', 'group C', 'group D', 'group E', 'group B',
           'group B', 'group D', 'group D', 'group A', 'group D', 'group C',
           'group E', 'group C', 'group D', 'group C', 'group B', 'group E',
           'group C', 'group D', 'group D', 'group C', 'group E', 'group A',
           'group D', 'group C', 'group B', 'group C', 'group D', 'group E',
           'group A', 'group A', 'group B', 'group D', 'group D', 'group C',
           'group E', 'group B', 'group B', 'group D', 'group B', 'group E',
           'group B', 'group C', 'group E', 'group C', 'group C', 'group B',
           'group B', 'group C', 'group A', 'group E', 'group D', 'group C',
           'group C', 'group C', 'group B', 'group C', 'group B', 'group D',
           'group C', 'group C', 'group E', 'group D', 'group C', 'group C',
           'group E', 'group D', 'group B', 'group C', 'group E', 'group D',
           'group B', 'group D', 'group C', 'group D', 'group C', 'group E',
           'group B', 'group B', 'group C', 'group D', 'group C', 'group B',
           'group C', 'group D', 'group E', 'group E', 'group B', 'group B',
           'group D', 'group C', 'group C', 'group C', 'group E', 'group B',
           'group E', 'group C', 'group B', 'group B', 'group D', 'group B',
           'group C', 'group D', 'group B', 'group E', 'group C', 'group D',
           'group A', 'group C', 'group D', 'group C', 'group B', 'group E',
           'group C', 'group D', 'group D', 'group D', 'group B', 'group C',
           'group D', 'group E', 'group D', 'group E', 'group D', 'group C',
           'group E', 'group B', 'group B', 'group C', 'group A', 'group D',
           'group B', 'group D', 'group D', 'group E', 'group C', 'group C',
           'group B', 'group C', 'group C', 'group C', 'group C', 'group E',
           'group D', 'group D', 'group C', 'group D', 'group D', 'group E',
           'group C', 'group C', 'group D', 'group D', 'group B', 'group C',
           'group C', 'group E', 'group C', 'group B', 'group D', 'group D',
           'group D', 'group D', 'group B', 'group B', 'group E', 'group B',
           'group B', 'group E', 'group C', 'group D', 'group C', 'group E',
           'group D', 'group B', 'group A', 'group E', 'group C', 'group D',
           'group A', 'group D', 'group C', 'group B', 'group C', 'group A',
           'group E', 'group C', 'group B', 'group D', 'group B', 'group B',
           'group D', 'group C', 'group C', 'group C', 'group D', 'group C',
           'group B', 'group D', 'group C', 'group E', 'group C', 'group C',
           'group C', 'group C', 'group C', 'group A', 'group C', 'group B',
           'group C', 'group C', 'group E', 'group B', 'group C', 'group B',
           'group D', 'group C', 'group B', 'group D', 'group C', 'group C',
           'group B', 'group D', 'group D', 'group C', 'group B', 'group C',
           'group D', 'group E', 'group B', 'group E', 'group C', 'group C',
           'group C', 'group B', 'group A', 'group C', 'group D', 'group D',
           'group B', 'group B', 'group C', 'group D', 'group C', 'group A',
           'group C', 'group C', 'group A', 'group D', 'group E', 'group C',
           'group D', 'group D', 'group D', 'group E', 'group D', 'group D',
           'group A', 'group A', 'group B', 'group C', 'group C', 'group E',
           'group A', 'group E', 'group E', 'group C', 'group D', 'group D',
           'group E', 'group D', 'group E', 'group C', 'group C', 'group A',
           'group B', 'group C', 'group B', 'group D', 'group C', 'group A',
           'group A', 'group D', 'group C', 'group C', 'group B', 'group B',
           'group D', 'group D', 'group D', 'group E', 'group D', 'group B',
           'group C', 'group E', 'group C', 'group C', 'group D', 'group E',
           'group C', 'group D', 'group D', 'group A', 'group B', 'group C',
           'group C', 'group C', 'group A', 'group C', 'group C', 'group C',
           'group C', 'group A', 'group C', 'group C', 'group D', 'group D',
           'group C', 'group D', 'group C', 'group D', 'group A', 'group B',
           'group A', 'group C', 'group D', 'group C', 'group B', 'group B',
           'group C', 'group E', 'group C', 'group C', 'group C', 'group C',
           'group D', 'group D', 'group E', 'group B', 'group C', 'group B',
           'group E', 'group C', 'group A', 'group C', 'group D', 'group A',
           'group A', 'group C', 'group C', 'group C', 'group C', 'group D',
           'group B', 'group D', 'group E', 'group D', 'group D', 'group E',
           'group B', 'group D', 'group C', 'group A', 'group B', 'group C',
           'group D', 'group C', 'group B', 'group A', 'group A', 'group C',
           'group C', 'group C', 'group B', 'group D', 'group C', 'group D',
           'group B', 'group E', 'group D', 'group B', 'group C', 'group E',
           'group D', 'group B', 'group A', 'group B', 'group C', 'group C',
           'group D', 'group A', 'group D', 'group B', 'group B', 'group C',
           'group D', 'group E', 'group D', 'group B', 'group D', 'group C',
           'group D', 'group C', 'group C', 'group E', 'group C', 'group C',
           'group D', 'group C', 'group C', 'group C', 'group E', 'group E',
           'group B', 'group C', 'group C', 'group D', 'group E', 'group A',
           'group C', 'group D', 'group C', 'group D', 'group D', 'group E',
           'group A', 'group C', 'group C', 'group C', 'group C', 'group B',
           'group B', 'group D', 'group E', 'group C', 'group C', 'group C',
           'group B', 'group D', 'group D', 'group C', 'group C', 'group D',
           'group B', 'group B', 'group E', 'group D', 'group B', 'group D',
           'group B', 'group A', 'group C', 'group C', 'group E', 'group A',
           'group A', 'group B', 'group B', 'group D', 'group D', 'group E',
           'group D', 'group D', 'group D', 'group C', 'group A', 'group C',
           'group C', 'group A', 'group C', 'group A', 'group E', 'group E',
           'group C', 'group C', 'group B', 'group A', 'group D', 'group D',
           'group D', 'group C', 'group E', 'group D', 'group D', 'group C',
           'group C', 'group C', 'group E', 'group B', 'group D', 'group C',
           'group C', 'group C', 'group A', 'group C', 'group E', 'group D',
           'group D', 'group C', 'group C', 'group B', 'group C', 'group A',
           'group E', 'group D', 'group B', 'group D', 'group D', 'group C',
           'group D', 'group B', 'group B', 'group C', 'group D', 'group A',
           'group B', 'group D', 'group E', 'group D', 'group D', 'group D',
           'group B', 'group E', 'group B', 'group B', 'group D', 'group E',
           'group B', 'group D', 'group C', 'group A', 'group D', 'group A',
           'group B', 'group B', 'group C', 'group D', 'group D', 'group D',
           'group C', 'group C', 'group D', 'group C', 'group D', 'group C',
           'group C', 'group B', 'group C', 'group D', 'group C', 'group D',
           'group C', 'group C', 'group D', 'group B', 'group E', 'group C',
           'group D', 'group D', 'group D', 'group B', 'group B', 'group C',
           'group B', 'group E', 'group E', 'group D', 'group A', 'group E',
           'group C', 'group E', 'group C', 'group D', 'group C', 'group D',
           'group C', 'group A', 'group D', 'group C', 'group E', 'group B',
           'group A', 'group D', 'group B', 'group A', 'group D', 'group C',
           'group D', 'group D', 'group C', 'group E', 'group D', 'group D',
           'group B', 'group B', 'group C', 'group C', 'group C', 'group E',
           'group C', 'group D', 'group B', 'group C', 'group B', 'group E',
           'group E', 'group E', 'group D', 'group C', 'group B', 'group A',
           'group C', 'group D', 'group E', 'group C', 'group C', 'group B',
           'group D', 'group C', 'group D', 'group A', 'group C', 'group C',
           'group B', 'group D', 'group D', 'group C', 'group C', 'group B',
           'group D', 'group E', 'group C', 'group C', 'group C', 'group E',
           'group D', 'group E', 'group D', 'group B', 'group C', 'group D',
           'group D', 'group B', 'group D', 'group B', 'group C', 'group B',
           'group D', 'group A', 'group B', 'group D', 'group B', 'group C',
           'group B', 'group B', 'group B', 'group C', 'group A', 'group E',
           'group D', 'group B', 'group B', 'group C', 'group C', 'group B',
           'group E', 'group B', 'group C', 'group C', 'group B', 'group D',
           'group D', 'group E', 'group B', 'group E', 'group D', 'group E',
           'group E', 'group C', 'group C', 'group C', 'group E', 'group B',
           'group C', 'group A', 'group D', 'group E', 'group C', 'group B',
           'group A', 'group A', 'group C', 'group E', 'group C', 'group B',
           'group A', 'group D', 'group B', 'group C', 'group A', 'group D',
           'group E', 'group B', 'group C', 'group C', 'group C', 'group C',
           'group D', 'group B', 'group A', 'group C', 'group A', 'group B',
           'group B', 'group C', 'group E', 'group A', 'group B', 'group C',
           'group D', 'group C', 'group B', 'group B', 'group D', 'group E',
           'group C', 'group D', 'group C', 'group D', 'group C', 'group A',
           'group E', 'group E', 'group C', 'group B', 'group B', 'group C',
           'group B', 'group C', 'group C', 'group E', 'group D', 'group C',
           'group C', 'group D', 'group C', 'group B', 'group E', 'group C',
           'group B', 'group C', 'group B', 'group E', 'group C', 'group C',
           'group D', 'group C', 'group D', 'group D', 'group C', 'group E',
           'group B', 'group D', 'group E', 'group C', 'group E', 'group C',
           'group D', 'group D', 'group E', 'group E', 'group A', 'group D',
           'group E', 'group E', 'group B', 'group B', 'group D', 'group D',
           'group D', 'group C', 'group A', 'group D', 'group D', 'group D',
           'group B', 'group D', 'group C', 'group E', 'group D', 'group A',
           'group C', 'group C', 'group B', 'group E', 'group E', 'group C',
           'group C', 'group B', 'group D', 'group C', 'group D', 'group B',
           'group D', 'group E', 'group E', 'group D', 'group E', 'group C',
           'group C', 'group D', 'group D', 'group C', 'group C', 'group D',
           'group A', 'group E', 'group D', 'group D', 'group C', 'group D',
           'group C', 'group A', 'group B', 'group C', 'group B', 'group D',
           'group B', 'group E', 'group E', 'group D', 'group E', 'group C',
           'group C', 'group E', 'group C', 'group D', 'group D', 'group C',
           'group A', 'group D', 'group E', 'group C', 'group D', 'group D',
           'group A', 'group C', 'group E', 'group B', 'group D', 'group C',
           'group A', 'group D', 'group A', 'group C', 'group B', 'group C',
           'group D', 'group C', 'group B', 'group D', 'group B', 'group A',
           'group C', 'group A', 'group C', 'group E', 'group A', 'group D',
           'group E', 'group B', 'group D', 'group D', 'group A', 'group E',
           'group C', 'group C', 'group D', 'group D'], dtype=object)




```python
#There are 5 different ethnic groups in the data frame, with group C appearing most and group A appearing least
df['race/ethnicity'].value_counts()
```




    group C    319
    group D    262
    group B    190
    group E    140
    group A     89
    Name: race/ethnicity, dtype: int64




```python
# 5 unique ethnic groups
df['race/ethnicity'].nunique()
```




    5




```python
df['race/ethnicity'].unique()
```




    array(['group B', 'group C', 'group A', 'group D', 'group E'],
          dtype=object)




```python
df['race/ethnicity'].mode()
```




    0    group C
    dtype: object




```python
df['race/ethnicity'].describe()
```




    count        1000
    unique          5
    top       group C
    freq          319
    Name: race/ethnicity, dtype: object




```python
#mean math score
m= math_mean= df['math score'].mean()
math_mean
```




    66.089




```python
m
```




    66.089




```python

```




    66.089




```python
#mean reading score
r= reading_mean= df['reading score'].mean()
reading_mean
```




    69.169




```python
#mean writing score
w=writing_mean= df['writing score'].mean()
writing_mean
```




    68.054




```python
df.gender.describe()
```




    count       1000
    unique         2
    top       female
    freq         518
    Name: gender, dtype: object






```python
#2 unique genders with more female than male
df.gender.value_counts()
```




    female    518
    male      482
    Name: gender, dtype: int64




```python
df.parental level of education.value_counts()
```


      File "<ipython-input-132-62dcad38ca88>", line 1
        df.parental level of education.value_counts()
                    ^
    SyntaxError: invalid syntax
    



```python
df.('parental_level_of_education')

```


      File "<ipython-input-21-576bd5ef0cad>", line 1
        df.('parental_level_of_education')
           ^
    SyntaxError: invalid syntax
    



```python
#df.parental_level_of_education was not responding, so i had to create my own series.
p=parental_level_of_education= df.iloc[:,2]
```


```python
p=parental_level_of_education
```


```python
p
```




    0       bachelor's degree
    1            some college
    2         master's degree
    3      associate's degree
    4            some college
                  ...        
    995       master's degree
    996           high school
    997           high school
    998          some college
    999          some college
    Name: parental level of education, Length: 1000, dtype: object




```python
# creating  a data frame of gender against mean of each scores
df.groupby('gender')[['math score','reading score','writing score']].mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>math score</th>
      <th>reading score</th>
      <th>writing score</th>
    </tr>
    <tr>
      <th>gender</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>female</th>
      <td>63.633205</td>
      <td>72.608108</td>
      <td>72.467181</td>
    </tr>
    <tr>
      <th>male</th>
      <td>68.728216</td>
      <td>65.473029</td>
      <td>63.311203</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>gender</th>
      <th>race/ethnicity</th>
      <th>parental level of education</th>
      <th>lunch</th>
      <th>test preparation course</th>
      <th>math score</th>
      <th>reading score</th>
      <th>writing score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>female</td>
      <td>group B</td>
      <td>bachelor's degree</td>
      <td>standard</td>
      <td>none</td>
      <td>72</td>
      <td>72</td>
      <td>74</td>
    </tr>
    <tr>
      <th>1</th>
      <td>female</td>
      <td>group C</td>
      <td>some college</td>
      <td>standard</td>
      <td>completed</td>
      <td>69</td>
      <td>90</td>
      <td>88</td>
    </tr>
    <tr>
      <th>2</th>
      <td>female</td>
      <td>group B</td>
      <td>master's degree</td>
      <td>standard</td>
      <td>none</td>
      <td>90</td>
      <td>95</td>
      <td>93</td>
    </tr>
    <tr>
      <th>3</th>
      <td>male</td>
      <td>group A</td>
      <td>associate's degree</td>
      <td>free/reduced</td>
      <td>none</td>
      <td>47</td>
      <td>57</td>
      <td>44</td>
    </tr>
    <tr>
      <th>4</th>
      <td>male</td>
      <td>group C</td>
      <td>some college</td>
      <td>standard</td>
      <td>none</td>
      <td>76</td>
      <td>78</td>
      <td>75</td>
    </tr>
  </tbody>
</table>
</div>




```python
# grouping the scores by race/ethnicity
df.groupby('race/ethnicity')[['math score','reading score','writing score']].mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>math score</th>
      <th>reading score</th>
      <th>writing score</th>
    </tr>
    <tr>
      <th>race/ethnicity</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>group A</th>
      <td>61.629213</td>
      <td>64.674157</td>
      <td>62.674157</td>
    </tr>
    <tr>
      <th>group B</th>
      <td>63.452632</td>
      <td>67.352632</td>
      <td>65.600000</td>
    </tr>
    <tr>
      <th>group C</th>
      <td>64.463950</td>
      <td>69.103448</td>
      <td>67.827586</td>
    </tr>
    <tr>
      <th>group D</th>
      <td>67.362595</td>
      <td>70.030534</td>
      <td>70.145038</td>
    </tr>
    <tr>
      <th>group E</th>
      <td>73.821429</td>
      <td>73.028571</td>
      <td>71.407143</td>
    </tr>
  </tbody>
</table>
</div>




```python
#grouping the scores by test preparation score
df.groupby('test preparation course')[['math score','reading score','writing score']].mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>math score</th>
      <th>reading score</th>
      <th>writing score</th>
    </tr>
    <tr>
      <th>test preparation course</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>completed</th>
      <td>69.695531</td>
      <td>73.893855</td>
      <td>74.418994</td>
    </tr>
    <tr>
      <th>none</th>
      <td>64.077882</td>
      <td>66.534268</td>
      <td>64.504673</td>
    </tr>
  </tbody>
</table>
</div>




```python
#grouping the scores bylunch
df.groupby('lunch')[['math score','reading score','writing score']].mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>math score</th>
      <th>reading score</th>
      <th>writing score</th>
    </tr>
    <tr>
      <th>lunch</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>free/reduced</th>
      <td>58.921127</td>
      <td>64.653521</td>
      <td>63.022535</td>
    </tr>
    <tr>
      <th>standard</th>
      <td>70.034109</td>
      <td>71.654264</td>
      <td>70.823256</td>
    </tr>
  </tbody>
</table>
</div>




```python
 df.level of education
```


      File "<ipython-input-98-ea946ed1725f>", line 1
        df.level of education
                 ^
    SyntaxError: invalid syntax
    



```python
#graphical representation of the data
import matplotlib.pyplot as plt
```


```python
import numpy as np
import pandas as pd
```


```python
df= pd.read_csv('C:/Users/Hassan-Sodiq/Downloads/StudentsPerformance.csv')
```


```python

```


```python


```


```python
import pandas as pd
```


```python
from matplotlib import pyplot as plt
```


```python
df.gender
```




    0      female
    1      female
    2      female
    3        male
    4        male
            ...  
    995    female
    996      male
    997    female
    998    female
    999    female
    Name: gender, Length: 1000, dtype: object




```python
#confusion, just trying things out
female= df[df.gender=='female']
```


```python
female
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>gender</th>
      <th>race/ethnicity</th>
      <th>parental level of education</th>
      <th>lunch</th>
      <th>test preparation course</th>
      <th>math score</th>
      <th>reading score</th>
      <th>writing score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>female</td>
      <td>group B</td>
      <td>bachelor's degree</td>
      <td>standard</td>
      <td>none</td>
      <td>72</td>
      <td>72</td>
      <td>74</td>
    </tr>
    <tr>
      <th>1</th>
      <td>female</td>
      <td>group C</td>
      <td>some college</td>
      <td>standard</td>
      <td>completed</td>
      <td>69</td>
      <td>90</td>
      <td>88</td>
    </tr>
    <tr>
      <th>2</th>
      <td>female</td>
      <td>group B</td>
      <td>master's degree</td>
      <td>standard</td>
      <td>none</td>
      <td>90</td>
      <td>95</td>
      <td>93</td>
    </tr>
    <tr>
      <th>5</th>
      <td>female</td>
      <td>group B</td>
      <td>associate's degree</td>
      <td>standard</td>
      <td>none</td>
      <td>71</td>
      <td>83</td>
      <td>78</td>
    </tr>
    <tr>
      <th>6</th>
      <td>female</td>
      <td>group B</td>
      <td>some college</td>
      <td>standard</td>
      <td>completed</td>
      <td>88</td>
      <td>95</td>
      <td>92</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>993</th>
      <td>female</td>
      <td>group D</td>
      <td>bachelor's degree</td>
      <td>free/reduced</td>
      <td>none</td>
      <td>62</td>
      <td>72</td>
      <td>74</td>
    </tr>
    <tr>
      <th>995</th>
      <td>female</td>
      <td>group E</td>
      <td>master's degree</td>
      <td>standard</td>
      <td>completed</td>
      <td>88</td>
      <td>99</td>
      <td>95</td>
    </tr>
    <tr>
      <th>997</th>
      <td>female</td>
      <td>group C</td>
      <td>high school</td>
      <td>free/reduced</td>
      <td>completed</td>
      <td>59</td>
      <td>71</td>
      <td>65</td>
    </tr>
    <tr>
      <th>998</th>
      <td>female</td>
      <td>group D</td>
      <td>some college</td>
      <td>standard</td>
      <td>completed</td>
      <td>68</td>
      <td>78</td>
      <td>77</td>
    </tr>
    <tr>
      <th>999</th>
      <td>female</td>
      <td>group D</td>
      <td>some college</td>
      <td>free/reduced</td>
      <td>none</td>
      <td>77</td>
      <td>86</td>
      <td>86</td>
    </tr>
  </tbody>
</table>
<p>518 rows × 8 columns</p>
</div>




```python
female['race/ethnicity'].value_counts()
```




    group C    180
    group D    129
    group B    104
    group E     69
    group A     36
    Name: race/ethnicity, dtype: int64




```python
female['race/ethnicity'].dtype()
```


    ---------------------------------------------------------------------------

    TypeError                                 Traceback (most recent call last)

    <ipython-input-56-739957962496> in <module>
    ----> 1 female['race/ethnicity'].dtype()
    

    TypeError: 'numpy.dtype[object_]' object is not callable



```python
# trial and clear ERROR
female
y=female.iloc[:,5]
x=female.iloc[:,1]
plt.plot(x,y)
plt.show()
```


    
![png](output_54_0.png)
    



```python

```


```python
#From this bar, it can be inferred that race C has the highest population of students, and race A the lowest.
df['race/ethnicity'].value_counts().plot.bar()
```




    <AxesSubplot:>




    
![png](output_56_1.png)
    



```python
plt.subplot()
df['race/ethnicity'].value_counts().plot.bar()
plt.subplot()
df['gender'].value_counts().plot.bar()
plt.subplot()
df['lunch'].value_counts().plot.bar()
plt.subplot()
df['test preparation course'].value_counts().plot.bar()
plt.show()
```

    <ipython-input-135-8a7f790055b2>:3: MatplotlibDeprecationWarning: Adding an axes using the same arguments as a previous axes currently reuses the earlier instance.  In a future version, a new instance will always be created and returned.  Meanwhile, this warning can be suppressed, and the future behavior ensured, by passing a unique label to each axes instance.
      plt.subplot()
    <ipython-input-135-8a7f790055b2>:5: MatplotlibDeprecationWarning: Adding an axes using the same arguments as a previous axes currently reuses the earlier instance.  In a future version, a new instance will always be created and returned.  Meanwhile, this warning can be suppressed, and the future behavior ensured, by passing a unique label to each axes instance.
      plt.subplot()
    <ipython-input-135-8a7f790055b2>:7: MatplotlibDeprecationWarning: Adding an axes using the same arguments as a previous axes currently reuses the earlier instance.  In a future version, a new instance will always be created and returned.  Meanwhile, this warning can be suppressed, and the future behavior ensured, by passing a unique label to each axes instance.
      plt.subplot()
    


    
![png](output_57_1.png)
    



```python

```


```python
# the population of female student is more than the male.
df['gender'].value_counts().plot.bar()
```




    <AxesSubplot:>




    
![png](output_59_1.png)
    



```python
#population of students who had standard lunch is more than those who had free/ reduced.
df['lunch'].value_counts().plot.bar()
```




    <AxesSubplot:>




    
![png](output_60_1.png)
    



```python
# more students had no test preparation course 
df['test preparation course'].value_counts().plot.bar()
```




    <AxesSubplot:>




    
![png](output_61_1.png)
    



```python
#since the horizontal green line represent the median, the reading score has higher median compared to math score and writing score
#the tiny circles represent outliers, saying students can score really low grades
df.boxplot()
```




    <AxesSubplot:>




    
![png](output_62_1.png)
    



```python

```


```python
import seaborn as sns
```


```python
#mean math score is about 65
sns.displot(df['math score'])
```




    <seaborn.axisgrid.FacetGrid at 0x27bbd97d0a0>




    
![png](output_65_1.png)
    



```python
#mean reading score is about 68
sns.displot(df['reading score'])
```




    <seaborn.axisgrid.FacetGrid at 0x27bbd8939a0>




    
![png](output_66_1.png)
    



```python
sns.displot(df['writing score'])
```




    <seaborn.axisgrid.FacetGrid at 0x27bbe3555e0>




    
![png](output_67_1.png)
    



```python
# There is really strong correlation between the 3 scores, as the correlation coefficeients are all greater than 0.8
corr = df.corr()
sns.heatmap(corr, annot=True, square=True)
plt.plot(figsize=(20,8))
plt.show()
```


    
![png](output_68_0.png)
    



```python
sns.relplot(x='math score', y='writing score', hue='gender', data=df)
```




    <seaborn.axisgrid.FacetGrid at 0x27bbd937c10>




    
![png](output_69_1.png)
    



```python
sns.relplot(x='math score', y='writing score', hue='race/ethnicity', data=df)
```




    <seaborn.axisgrid.FacetGrid at 0x27bbd937cd0>




    
![png](output_70_1.png)
    



```python
sns.relplot(x='math score', y='writing score', hue='lunch', data=df)
```




    <seaborn.axisgrid.FacetGrid at 0x27bbe354d30>




    
![png](output_71_1.png)
    



```python
 #plot the dataframe
df.plot(x="gender", y=["math score", "reading score"], kind="bar", figsize=(20, 8))
  
# print bar graph
plt.show()
```


    
![png](output_72_0.png)
    



```python
plt.show()
```


```python
df.groupby('parental level of education')[['math score', 'reading score', 'writing score']].mean()


```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>math score</th>
      <th>reading score</th>
      <th>writing score</th>
    </tr>
    <tr>
      <th>parental level of education</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>associate's degree</th>
      <td>67.882883</td>
      <td>70.927928</td>
      <td>69.896396</td>
    </tr>
    <tr>
      <th>bachelor's degree</th>
      <td>69.389831</td>
      <td>73.000000</td>
      <td>73.381356</td>
    </tr>
    <tr>
      <th>high school</th>
      <td>62.137755</td>
      <td>64.704082</td>
      <td>62.448980</td>
    </tr>
    <tr>
      <th>master's degree</th>
      <td>69.745763</td>
      <td>75.372881</td>
      <td>75.677966</td>
    </tr>
    <tr>
      <th>some college</th>
      <td>67.128319</td>
      <td>69.460177</td>
      <td>68.840708</td>
    </tr>
    <tr>
      <th>some high school</th>
      <td>63.497207</td>
      <td>66.938547</td>
      <td>64.888268</td>
    </tr>
  </tbody>
</table>
</div>




```python
#the highest scores were by students of parents with higher degree(associate, bachelor's, master's),  this might be because students were getting better support from home, since higher level of education
df.groupby('parental level of education')[['math score', 'reading score', 'writing score']].mean().T.plot(figsize=(10,8))
```




    <AxesSubplot:>




    
![png](output_75_1.png)
    



```python
#same infromationm as above in horizontak bar graph
df.groupby('parental level of education')[['math score', 'reading score', 'writing score']].mean().plot.barh(figsize=(10,8))
```




    <AxesSubplot:ylabel='parental level of education'>




    
![png](output_76_1.png)
    



```python
df.groupby('race/ethnicity')[['math score', 'reading score', 'writing score']].mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>math score</th>
      <th>reading score</th>
      <th>writing score</th>
    </tr>
    <tr>
      <th>race/ethnicity</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>group A</th>
      <td>61.629213</td>
      <td>64.674157</td>
      <td>62.674157</td>
    </tr>
    <tr>
      <th>group B</th>
      <td>63.452632</td>
      <td>67.352632</td>
      <td>65.600000</td>
    </tr>
    <tr>
      <th>group C</th>
      <td>64.463950</td>
      <td>69.103448</td>
      <td>67.827586</td>
    </tr>
    <tr>
      <th>group D</th>
      <td>67.362595</td>
      <td>70.030534</td>
      <td>70.145038</td>
    </tr>
    <tr>
      <th>group E</th>
      <td>73.821429</td>
      <td>73.028571</td>
      <td>71.407143</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.groupby('race/ethnicity')[['math score', 'reading score', 'writing score']].mean().T.plot(figsize=(12,8))
```




    <AxesSubplot:>




    
![png](output_78_1.png)
    



```python
#ethnic group E had the average highest scores
df.groupby('race/ethnicity')[['math score', 'reading score', 'writing score']].mean().plot.barh(figsize=(12,8))
```




    <AxesSubplot:ylabel='race/ethnicity'>




    
![png](output_79_1.png)
    



```python
# the large difference is visible in this line graph of the effect of lunch on the rest score. standatrd lunch yielded better result
.df.groupby('lunch')[['math score', 'reading score', 'writing score']].mean().T.plot(figsize=(12,8))
```




    <AxesSubplot:>




    
![png](output_80_1.png)
    



```python
df.groupby('lunch')[['math score', 'reading score', 'writing score']].mean().T.plot.barh(figsize=(12,8))
```




    <AxesSubplot:>




    
![png](output_81_1.png)
    



```python
df.groupby('test preparation course')[['math score', 'reading score', 'writing score']].mean().T.plot(figsize=(12,8))
```




    <AxesSubplot:>




    
![png](output_82_1.png)
    



```python
#those who took the preparation course did better, practice makes perfect.
df.groupby('test preparation course')[['math score', 'reading score', 'writing score']].mean().T.plot.barh(figsize=(12,8))
```




    <AxesSubplot:>




    
![png](output_83_1.png)
    



```python
df.groupby('test preparation course')[['math score', 'reading score', 'writing score']].mean().plot.bar(figsize=(12,8))
```




    <AxesSubplot:xlabel='test preparation course'>




    
![png](output_84_1.png)
    



```python
df.groupby('test preparation course')[['math score', 'reading score', 'writing score']].mean().plot.barh(figsize=(12,8))
```




    <AxesSubplot:ylabel='test preparation course'>




    
![png](output_85_1.png)
    



```python
df.groupby('parental level of education')[['math score', 'reading score', 'writing score']].mean().T.plot(figsize=(12,8))
```




    <AxesSubplot:>




    
![png](output_86_1.png)
    



```python
df.groupby('gender')[['math score', 'reading score', 'writing score']].mean().T.plot(figsize=(12,8))
```




    <AxesSubplot:>




    
![png](output_87_1.png)
    



```python
df[['gender','math score', 'reading score', 'writing score']]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>gender</th>
      <th>math score</th>
      <th>reading score</th>
      <th>writing score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>female</td>
      <td>72</td>
      <td>72</td>
      <td>74</td>
    </tr>
    <tr>
      <th>1</th>
      <td>female</td>
      <td>69</td>
      <td>90</td>
      <td>88</td>
    </tr>
    <tr>
      <th>2</th>
      <td>female</td>
      <td>90</td>
      <td>95</td>
      <td>93</td>
    </tr>
    <tr>
      <th>3</th>
      <td>male</td>
      <td>47</td>
      <td>57</td>
      <td>44</td>
    </tr>
    <tr>
      <th>4</th>
      <td>male</td>
      <td>76</td>
      <td>78</td>
      <td>75</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>female</td>
      <td>88</td>
      <td>99</td>
      <td>95</td>
    </tr>
    <tr>
      <th>996</th>
      <td>male</td>
      <td>62</td>
      <td>55</td>
      <td>55</td>
    </tr>
    <tr>
      <th>997</th>
      <td>female</td>
      <td>59</td>
      <td>71</td>
      <td>65</td>
    </tr>
    <tr>
      <th>998</th>
      <td>female</td>
      <td>68</td>
      <td>78</td>
      <td>77</td>
    </tr>
    <tr>
      <th>999</th>
      <td>female</td>
      <td>77</td>
      <td>86</td>
      <td>86</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 4 columns</p>
</div>




```python
df.describe(include='all')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>gender</th>
      <th>race/ethnicity</th>
      <th>parental level of education</th>
      <th>lunch</th>
      <th>test preparation course</th>
      <th>math score</th>
      <th>reading score</th>
      <th>writing score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000.00000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>2</td>
      <td>5</td>
      <td>6</td>
      <td>2</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>top</th>
      <td>female</td>
      <td>group C</td>
      <td>some college</td>
      <td>standard</td>
      <td>none</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>518</td>
      <td>319</td>
      <td>226</td>
      <td>645</td>
      <td>642</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>66.08900</td>
      <td>69.169000</td>
      <td>68.054000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>15.16308</td>
      <td>14.600192</td>
      <td>15.195657</td>
    </tr>
    <tr>
      <th>min</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.00000</td>
      <td>17.000000</td>
      <td>10.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>57.00000</td>
      <td>59.000000</td>
      <td>57.750000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>66.00000</td>
      <td>70.000000</td>
      <td>69.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>77.00000</td>
      <td>79.000000</td>
      <td>79.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>100.00000</td>
      <td>100.000000</td>
      <td>100.000000</td>
    </tr>
  </tbody>
</table>
</div>


